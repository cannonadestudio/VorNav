# brak specjalnych reguł
